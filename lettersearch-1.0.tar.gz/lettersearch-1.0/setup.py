# -*- coding: utf-8 -*-
"""
Created on Tue Oct  3 04:33:34 2023

@author: pq
"""

from setuptools import setup
setup(name='lettersearch', version='1.0', py_modules=['lettersearch'])
